import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.*;
import java.util.ArrayList;
import java.util.Scanner;

public class Compiler {
    public static void main(String[] args) throws IOException {
        File file = new File("testfile.txt");
        if (!file.exists()) {
            System.out.println("Filename error");
            System.exit(0);
        }
        String content = readFile(file);
        LexicalAnalyzer lexicalAnalyzer = new LexicalAnalyzer(content);
        ArrayList<LexicalAnalyzerForm> lexicalAnalyzerForms = lexicalAnalyzer.LexicalAnalyze(false, "output.txt");
        //System.out.println(lexicalAnalyzerForms);
        GrammerAnalyzer grammerAnalyzer = new GrammerAnalyzer(lexicalAnalyzerForms);
        grammerAnalyzer.eofile(true, "output.txt");
//        Scanner input = new Scanner(file);
//        while (input.hasNext()){
//        }
//        input.close();
    }
    public static String readFile(File file){
        BufferedReader reader = null;
        StringBuilder sbd = new StringBuilder();
        try{
            reader = new BufferedReader(new FileReader(file));
            String tempStr;
            while ((tempStr = reader.readLine()) != null) {
                sbd.append(tempStr).append("\n");
            }
            reader.close();
            return sbd.toString();
        }catch(IOException e){
            e.printStackTrace();
        }finally {
            if (reader != null){
                try{
                    reader.close();
                }catch (IOException e){
                    e.printStackTrace();;
                }
            }
        }
        return sbd.toString();
    }

}
