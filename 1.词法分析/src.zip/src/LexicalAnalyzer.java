import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

public class LexicalAnalyzer {
    public String content;

    public LexicalAnalyzer(String content) {
        this.content = content;
    }

    public String getContent() {
        return content;
    }

    public void eofile(ArrayList<LexicalAnalyzerForm> res, String outFileName) throws IOException{
        StringBuilder buf = new StringBuilder();
        for (int i = 0; i < res.size(); i++){
            if (i != res.size() - 1){
                buf.append(res.get(i).turnToFileFormat()).append("\n");
            }
            else{
                buf.append(res.get(i).turnToFileFormat());
            }
        }
        File file = new File(outFileName);
        FileWriter fileWritter = new FileWriter(file.getName(),false);
        fileWritter.write(buf.toString());
        fileWritter.close();
    }

    public boolean judgeNum(char chara) {
        return Character.isDigit(chara);
    }

    //1a is not word, a1 is word
    public boolean judgeWordThen(char chara) {
        return ((int) chara >= 65 && (int) chara <= 90) || (int) chara == 95 || ((int) chara >= 97 && (int) chara <= 122) || Character.isDigit(chara);
    }

    public boolean judgeWordFirst(char chara) {
        return ((int) chara >= 65 && (int) chara <= 90) || (int) chara == 95 || ((int) chara >= 97 && (int) chara <= 122);
    }

    public boolean judgeSingleSym(char chara) {
        return chara == '!' || chara == '&' || chara == '|' || chara == '+' || chara == '-' || chara == '*' || chara == '%'
                || chara == '<' || chara == '>' || chara == '=' || chara == ';' || chara == ',' || chara == '(' || chara == ')'
                || chara == '[' || chara == ']' || chara == '{' || chara == '}';
    }

    public boolean judgeDoubleSym(char chara) {
        return chara == '!' || chara == '&' || chara == '|' || chara == '>' || chara == '<' || chara == '=';
    }

    public boolean judgeFormatChar(char chara) {
        return ((int) chara == 32) || ((int) chara == 33) || chara == '%' || ((int) chara >= 40 && (int) chara <= 126) || chara == '\n';
    }

    public ArrayList<LexicalAnalyzerForm> LexicalAnalyze(boolean eof, String outFileName) throws IOException {
        ArrayList<LexicalAnalyzerForm> res = new ArrayList<>();
        for (int i = 0; i < content.length(); i++) {
            char chara = content.charAt(i);
            //judge if is number
            if (judgeNum(chara)) {
                StringBuilder buf = new StringBuilder();
                for (int j = i; j < content.length(); j++) {
                    char tmp = content.charAt(j);
                    if (judgeNum(tmp)) {
                        buf.append(tmp);
                    } else {
                        i = j - 1;
                        break;
                    }
                }
                res.add(new LexicalAnalyzerForm(buf.toString(), 2));
            }

            //judge if is alphabet
            else if (judgeWordFirst(chara)) {
                StringBuilder buf = new StringBuilder();
                for (int j = i; j < content.length(); j++) {
                    char tmp = content.charAt(j);
                    if (judgeWordThen(tmp)) {
                        buf.append(tmp);
                    } else {
                        i = j - 1;
                        break;
                    }
                }
                res.add(new LexicalAnalyzerForm(buf.toString(), 1));
            }

            //judge if is sym
            else if (judgeSingleSym(chara)) {
                StringBuilder buf = new StringBuilder();
                for (int j = i; j < content.length(); j++) {
                    char tmp = content.charAt(j);
                    if (judgeSingleSym(tmp)) {
                        if (judgeDoubleSym(tmp)) {
                            if (tmp == '&') {
                                // &&
                                if (content.charAt(j + 1) == '&' && j + 1 < content.length()) {
                                    res.add(new LexicalAnalyzerForm("&&", 1));
                                    j++;
                                }
                                // &
                                else {
                                    res.add(new LexicalAnalyzerForm("&", 1));
                                }
                            } else if (tmp == '|') {
                                // ||
                                if (content.charAt(j + 1) == '|' && j + 1 < content.length()) {
                                    res.add(new LexicalAnalyzerForm("||", 1));
                                    j++;
                                }
                                // |
                                else {
                                    res.add(new LexicalAnalyzerForm("|", 1));
                                }
                            } else if (tmp == '<') {
                                // <=
                                if (content.charAt(j + 1) == '=' && j + 1 < content.length()) {
                                    res.add(new LexicalAnalyzerForm("<=", 1));
                                    j++;
                                }
                                // <
                                else {
                                    res.add(new LexicalAnalyzerForm("<", 1));
                                }
                            } else if (tmp == '>') {
                                // >=
                                if (content.charAt(j + 1) == '=' && j + 1 < content.length()) {
                                    res.add(new LexicalAnalyzerForm(">=", 1));
                                    j++;
                                }
                                // >
                                else {
                                    res.add(new LexicalAnalyzerForm(">", 1));
                                }
                            } else if (tmp == '=') {
                                // ==
                                if (content.charAt(j + 1) == '=' && j + 1 < content.length()) {
                                    res.add(new LexicalAnalyzerForm("==", 1));
                                    j++;
                                }
                                // =
                                else {
                                    res.add(new LexicalAnalyzerForm("=", 1));
                                }
                            } else if (tmp == '!') {
                                // !=
                                if (content.charAt(j + 1) == '=' && j + 1 < content.length()) {
                                    res.add(new LexicalAnalyzerForm("!=", 1));
                                    j++;
                                }
                                // =
                                else {
                                    res.add(new LexicalAnalyzerForm("!", 1));
                                }
                            }
                        } else {
                            res.add(new LexicalAnalyzerForm(tmp + "", 1));
                        }
                    } else {
                        i = j - 1;
                        break;
                    }
                }
            }

            //judge format
            else if (chara == '\"') {
                StringBuilder buf = new StringBuilder();
                buf.append(chara);
                for (int j = i + 1; j < content.length(); j++) {
                    char tmp = content.charAt(j);
                    if (judgeFormatChar(tmp) && tmp != '\"') {
                        // format \n
                        if (tmp == '\\') {
                            if (content.charAt(j + 1) == 'n' && j + 1 < content.length()) {
                                buf.append(tmp);
                            }
                            else {
                                System.out.println("error1");
                            }
                        }
                        // %d
                        else if (tmp == '%') {
                            if (content.charAt(j + 1) == 'd' && j + 1 < content.length()) {
                                buf.append(tmp);
                            } else {
                                System.out.println("error2");
                            }
                        }
                        // buffer \n
                        else if (tmp == '\n'){
                        }
                        else{
                            buf.append(tmp);
                        }
                    }
                    else if (tmp == '\"'){
                        buf.append(tmp);
                        i = j;
                        break;
                    }
                    else{
                        System.out.println("error3");
                    }
                }
                res.add(new LexicalAnalyzerForm(buf.toString(), 3));
            }

            //judge \n
            else if (chara == '\n'){
                //continue;
            }

            //judge comment
            else if (chara == '/'){
                if (i + 1 < content.length()){
                    i++;
                    if (content.charAt(i) == '/') {
                        for (i = i + 1; i < content.length(); i++){
                            if (content.charAt(i) == '\n'){
                                break;
                            }
                        }
                    }
                    else if (content.charAt(i) == '*') {
                        for (i = i + 1; i< content.length() - 1; i++){
                            if (content.charAt(i) == '*' && content.charAt(i + 1) == '/'){
                                i++;
                                break;
                            }
                            if (content.charAt(i) == '\n'){
                                //continue;
                            }
                        }
                    }
                    else{
                        res.add(new LexicalAnalyzerForm(chara + "", 1));
                        i--;
                    }
                }
                else{
                    res.add(new LexicalAnalyzerForm(chara + "", 1));
                    System.out.println("error4");
                }
            }

            else {
                if (chara != ' ' && chara != '\t') {
                    System.out.println("error5");
                }
            }
        }
        if (eof){
            eofile(res, outFileName);
        }
        return res;
    }
}
