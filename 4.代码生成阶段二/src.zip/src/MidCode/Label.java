package MidCode;

public class Label {
    private int point = 0;

    public Label(){

    }

    public int getPoint() {
        return point;
    }

    public void setPoint(int point) {
        this.point = point;
    }
}
